public class PairString{
    String first;
    String second;
    public PairString(String first, String second){
        this.first = first;
        this.second = second;
    }
    public String getFirst() {
        return first;
    }
    public String getSecond() {
        return second;
    }
}
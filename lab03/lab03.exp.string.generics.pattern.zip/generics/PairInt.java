public class PairInt {
    Integer first;
    Integer second;
    public PairInt(Integer first, Integer second){
        this.first = first;
        this.second = second;
    }
    public Integer getFirst() {
        return first;
    }
    public Integer getSecond() {
        return second;
    }
}
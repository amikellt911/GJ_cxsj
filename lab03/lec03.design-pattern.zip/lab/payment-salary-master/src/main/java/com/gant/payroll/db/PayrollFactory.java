package com.gant.payroll.db;

/**
 * 构建主要对象类
 * 
 * @author jiangyp
 *
 */
public interface PayrollFactory {

	void createEmployee();
}

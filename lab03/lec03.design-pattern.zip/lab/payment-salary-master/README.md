# [薪水支付案例文档](https://www.zybuluo.com/jyp10/note/1182534)

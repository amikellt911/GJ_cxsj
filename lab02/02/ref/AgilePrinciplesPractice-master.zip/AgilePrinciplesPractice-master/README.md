# AgilePrinciplesPractice
無暇的程式碼-敏捷完整篇 (Agile Principles , Patterns and Practice In C# ) 練習

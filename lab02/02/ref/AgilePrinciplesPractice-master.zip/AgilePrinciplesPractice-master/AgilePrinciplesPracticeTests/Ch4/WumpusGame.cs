﻿using System;

namespace AgilePrinciplesPracticeTests.Ch4
{
    public class WumpusGame
    {
        public double GetPlayerRoom(int i)
        {
            throw new NotImplementedException();
        }

        public void East()
        {
            throw new NotImplementedException();
        }

        public double GetPlayerRoom()
        {
            throw new NotImplementedException();
        }

        internal void Connect(int v1, int v2, string v3)
        {
            throw new NotImplementedException();
        }
    }
}
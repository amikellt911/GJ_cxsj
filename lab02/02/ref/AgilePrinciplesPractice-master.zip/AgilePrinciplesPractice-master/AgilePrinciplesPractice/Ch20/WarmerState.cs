﻿namespace AgilePrinciplesPractice.Ch20
{
    public enum WarmerState
    {
        ON,
        OFF
    }
}
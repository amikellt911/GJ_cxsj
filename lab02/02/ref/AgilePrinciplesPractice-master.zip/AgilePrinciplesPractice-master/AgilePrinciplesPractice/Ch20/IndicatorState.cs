﻿namespace AgilePrinciplesPractice.Ch20
{
    public enum IndicatorState
    {
        ON,
        OFF
    }
}
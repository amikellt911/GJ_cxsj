﻿namespace AgilePrinciplesPractice.Ch20
{
    public enum BoilerStatus
    {
        EMPTY,
        NOT_EMPTY
    }
}
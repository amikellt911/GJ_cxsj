﻿namespace AgilePrinciplesPractice.Ch20
{
    public enum ReliefValveState
    {
        OPEN,
        CLOSED
    }
}
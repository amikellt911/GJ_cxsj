﻿namespace AgilePrinciplesPractice.Ch20
{
    public enum BrewButtonStatus
    {
        PUSHED,
        NOT_PUSHED
    }
}
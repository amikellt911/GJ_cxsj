﻿namespace AgilePrinciplesPractice.Ch20
{
    public enum BoilerState
    {
        ON,
        OFF
    }
}
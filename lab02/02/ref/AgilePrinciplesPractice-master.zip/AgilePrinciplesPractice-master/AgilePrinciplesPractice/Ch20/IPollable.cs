﻿namespace AgilePrinciplesPractice.Ch20
{
    internal interface IPollable
    {
        void Poll();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgilePrinciplesPractice.Ch35.Visitor
{
    public class ModemVisitor
    {
        public void Visit(Modem m)
        {
        }
    }
}
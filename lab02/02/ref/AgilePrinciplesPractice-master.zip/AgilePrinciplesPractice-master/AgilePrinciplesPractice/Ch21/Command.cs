﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgilePrinciplesPractice.Ch21
{
    public interface Command
    {
        void Execute();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgilePrinciplesPractice.Ch25
{
    public class DB
    {
        public static Employee GetEmployee(string s)
        {
            return Employee.NULL;
        }
    }
}
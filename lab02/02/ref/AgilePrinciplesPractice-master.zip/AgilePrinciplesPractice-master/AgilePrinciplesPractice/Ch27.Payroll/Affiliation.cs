namespace Payroll
{
	public interface Affiliation
	{
		double CalculateDeductions(Paycheck paycheck);
	}
}